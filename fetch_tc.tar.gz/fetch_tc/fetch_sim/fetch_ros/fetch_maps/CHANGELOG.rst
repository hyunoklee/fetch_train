^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package fetch_maps
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.7.0 (2015-09-29)
------------------
* Create fetch_maps package
* Contributors: Aaron Blasdel, Michael Ferguson
