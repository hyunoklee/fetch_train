^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package fetch_navigation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.7.0 (2015-09-29)
------------------
* Use fetch_maps package for maps
* Allow overriding of move base & amcl param files
* Contributors: Aaron Blasdel, Ian Danforth

0.6.2 (2015-07-30)
------------------

0.6.1 (2015-07-03)
------------------

0.6.0 (2015-06-23)
------------------

0.5.14 (2015-06-19)
-------------------
* fetch_navigation depends fetch_depth_layer
* Contributors: Michael Ferguson

0.5.13 (2015-06-13)
-------------------

0.5.12 (2015-06-12)
-------------------
* Slam_karto node rename in launch
* Contributors: Aaron Blasdel

0.5.11 (2015-06-10)
-------------------

0.5.10 (2015-06-07)
-------------------

0.5.9 (2015-06-07)
------------------

0.5.8 (2015-06-07)
------------------

0.5.7 (2015-06-05)
------------------
* display whole global plan
* Contributors: Michael Ferguson

0.5.6 (2015-06-04)
------------------
* remap static_map service for keepout server
* Contributors: Michael Ferguson

0.5.5 (2015-06-03)
------------------
* import navigation
* Contributors: Michael Ferguson
