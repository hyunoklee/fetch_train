^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package fetch_moveit_config
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.7.0 (2015-09-29)
------------------
* fix dependency issue with run/test duplication
* add missing moveit_python depend
* fix name of gripper fingers in fake controllers
* Contributors: Michael Ferguson

0.6.2 (2015-07-30)
------------------

0.6.1 (2015-07-03)
------------------
* add (optional) octomap configuration
* Contributors: Michael Ferguson

0.6.0 (2015-06-23)
------------------

0.5.14 (2015-06-19)
-------------------

0.5.13 (2015-06-13)
-------------------

0.5.12 (2015-06-12)
-------------------

0.5.11 (2015-06-10)
-------------------

0.5.10 (2015-06-07)
-------------------

0.5.9 (2015-06-07)
------------------

0.5.8 (2015-06-07)
------------------

0.5.7 (2015-06-05)
------------------
* bump joint limits used for moveit
* Contributors: Michael Ferguson

0.5.6 (2015-06-04)
------------------

0.5.5 (2015-06-03)
------------------

0.5.4 (2015-05-09)
------------------
* repository cleanup

0.5.3 (2015-05-03)
------------------

0.5.2 (2015-04-19)
------------------

0.5.1 (2015-04-09)
------------------

0.5.0 (2015-04-04)
------------------
* First public release
* Contributors: Michael Ferguson
