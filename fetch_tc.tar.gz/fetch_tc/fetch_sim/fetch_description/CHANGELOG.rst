^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package fetch_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.7.0 (2015-09-29)
------------------
* update limits of wrist flex
* remove duplicated inertia entries, fixes `#14 <https://github.com/fetchrobotics/fetch_ros/issues/14>`_
* Contributors: Michael Ferguson

0.6.2 (2015-07-30)
------------------

0.6.1 (2015-07-03)
------------------
* specify a license
* Contributors: Michael Ferguson

0.6.0 (2015-06-23)
------------------

0.5.14 (2015-06-19)
-------------------

0.5.13 (2015-06-13)
-------------------
* add dynamics to arm joints for simulation
* Contributors: Michael Ferguson

0.5.12 (2015-06-12)
-------------------

0.5.11 (2015-06-10)
-------------------
* remove laser opening from collision mesh
* Contributors: Michael Ferguson

0.5.10 (2015-06-07)
-------------------

0.5.9 (2015-06-07)
------------------

0.5.8 (2015-06-07)
------------------

0.5.7 (2015-06-05)
------------------

0.5.6 (2015-06-04)
------------------

0.5.5 (2015-06-03)
------------------

0.5.4 (2015-05-09)
------------------
* repository cleanup

0.5.3 (2015-05-03)
------------------
* Update head tilt range
* Contributors: Aaron Blasdel

0.5.2 (2015-04-19)
------------------

0.5.1 (2015-04-09)
------------------

0.5.0 (2015-04-04)
------------------

0.4.2 (2015-03-23)
------------------

0.4.1 (2015-03-23)
------------------
* update velocity limits of base motors
* Contributors: Michael Ferguson

0.4.0 (2015-03-22)
------------------

0.3.2 (2015-03-21)
------------------
* update limits of shoulder lift joint
* Contributors: Michael Ferguson

0.3.1 (2015-03-13 19:53)
------------------------
* fixup install
* Contributors: Michael Ferguson

0.3.0 (2015-03-13 18:59)
------------------------
* first release
* Contributors: Michael Ferguson
