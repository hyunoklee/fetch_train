^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package openai_ros
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.0 (2018-07-11)
------------------
* Not generated with BitBucket
