openai_ros.task_envs.shadow_tc package
======================================

Submodules
----------

openai_ros.task_envs.shadow_tc.learn_to_pick_ball module
--------------------------------------------------------

.. automodule:: openai_ros.task_envs.shadow_tc.learn_to_pick_ball
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: openai_ros.task_envs.shadow_tc
    :members:
    :undoc-members:
    :show-inheritance:
