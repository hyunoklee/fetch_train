## Install Dependencies

Execute the following commands:<br>
`cd ~/ros_ws/src`<br>
`git clone https://bitbucket.org/theconstructcore/openai_ros.git`<br>
`cd ~/ros_ws`<br>
`catkin_make`<br>
`source devel/setup.bash`<br>
`rosdep install openai_ros`<br>


## Use





